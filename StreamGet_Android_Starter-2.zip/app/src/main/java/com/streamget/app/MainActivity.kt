package com.streamget.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URL

private val Navy = Color(0xFF08111F)
private val Blue = Color(0xFF1687FF)
private val Card = Color(0xFF101C2D)

data class DownloadItem(val url: String, val name: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StreamGetApp(this) }
    }
}

@Composable
fun StreamGetApp(context: Context) {
    var url by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var status by remember { mutableStateOf("") }
    val history = remember { mutableStateListOf<DownloadItem>() }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue,
            background = Navy,
            surface = Card
        )
    ) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0B1727)) {
                    listOf("Home", "Downloads", "History", "Settings").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(if (i == 0) "⌂" else if (i == 1) "↓" else if (i == 2) "◷" else "⚙") },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen(
                        url = url,
                        onUrl = { url = it },
                        status = status,
                        onAnalyze = {
                            status = if (isDirectUrl(url)) "Direct media URL detected. Ready to download." else
                                "For this starter version, paste a direct media URL (MP4, MP3, WebM, etc.)."
                        },
                        onDownload = {
                            if (!isDirectUrl(url)) {
                                status = "Please use an authorized direct media URL."
                            } else {
                                val request = DownloadManager.Request(Uri.parse(url))
                                    .setTitle("StreamGet download")
                                    .setDescription("Downloading authorized media")
                                    .setNotificationVisibility(
                                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                                    )
                                    .setDestinationInExternalPublicDir(
                                        Environment.DIRECTORY_DOWNLOADS,
                                        "StreamGet_${System.currentTimeMillis()}"
                                    )
                                val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                dm.enqueue(request)
                                history.add(0, DownloadItem(url, "StreamGet download"))
                                status = "Download started. Check your Downloads folder."
                            }
                        }
                    )
                    1 -> SimpleListScreen("Downloads", listOf("Active downloads are managed by Android."))
                    2 -> HistoryScreen(history)
                    else -> SimpleListScreen("Settings", listOf("App name: StreamGet", "Version: 1.0", "Only download content you have permission to download."))
                }
            }
        }
    }
}

fun isDirectUrl(value: String): Boolean {
    return try {
        val u = URL(value)
        u.protocol == "http" || u.protocol == "https"
    } catch (_: Exception) { false }
}

@Composable
fun HomeScreen(
    url: String,
    onUrl: (String) -> Unit,
    status: String,
    onAnalyze: () -> Unit,
    onDownload: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(28.dp))
        Text("StreamGet", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Your authorized media downloader", color = Color.LightGray)
        Spacer(Modifier.height(36.dp))

        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Card)) {
            Column(Modifier.padding(18.dp)) {
                Text("Paste a media link", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = onUrl,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("https://example.com/video.mp4") }
                )
                Spacer(Modifier.height(14.dp))
                Button(onClick = onAnalyze, modifier = Modifier.fillMaxWidth()) {
                    Text("Analyze Link")
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = onDownload, modifier = Modifier.fillMaxWidth()) {
                    Text("Download")
                }
                if (status.isNotBlank()) {
                    Spacer(Modifier.height(14.dp))
                    Text(status, color = Color(0xFF8FD3FF), fontSize = 13.sp)
                }
            }
        }

        Spacer(Modifier.height(28.dp))
        Text("Features", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(8.dp))
        listOf("Clean modern interface", "Download history", "Android Download Manager", "Ready for a future authorized API backend")
            .forEach { Text("✓  $it", Modifier.fillMaxWidth().padding(vertical = 5.dp)) }
    }
}

@Composable
fun HistoryScreen(history: List<DownloadItem>) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("History", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (history.isEmpty()) Text("No downloads yet.", color = Color.LightGray)
        else LazyColumn { items(history) { Text(it.url, Modifier.padding(vertical = 10.dp), fontSize = 13.sp) } }
    }
}

@Composable
fun SimpleListScreen(title: String, items: List<String>) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        items.forEach { Text(it, Modifier.padding(vertical = 8.dp), color = Color.LightGray) }
    }
}
