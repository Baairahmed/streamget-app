# StreamGet Starter

A mobile-first Android starter for an authorized/direct-media downloader.

## Build
Open this project in Android Studio Cloud/Firebase Studio or another Android-capable cloud IDE.
Set your package name and branding before release.

## Important
This starter intentionally downloads direct media URLs using Android DownloadManager.
Do not add extraction/bypass logic for copyrighted or protected media without permission.
For Play Store publication, use original branding/content and comply with Google Play policies.
